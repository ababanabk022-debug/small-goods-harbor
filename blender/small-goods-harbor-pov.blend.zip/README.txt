Small Goods Harbor - Local POV model archive

Open small-goods-harbor-pov.blend in Blender 5.2.0 LTS.
The opening scene is Small Goods · Reference Harbor.
This archive includes the expanded main island and POV_ENVIRONMENT.
POV_ENVIRONMENT is hidden for the normal overview. Enable the collection
in the Outliner for editing or rendering the distant islands, reefs, clouds
and sailboats. The website shows this collection only in first-person mode.

The font is embedded. See FONT_NOTICES.txt. No external model resources
or MCP connection are required to open the scene.
The website sky, expanded water, fog and distant boat movement are runtime
JavaScript features and are not baked into this Blender archive.

See manifest.json for contents, checksums, verification scope and limitations.
