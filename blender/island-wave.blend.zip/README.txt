Island Wave - Editable Blender scene V1.0

Open island-wave.blend in Blender 5.2.0 LTS.
POV_ENVIRONMENT contains the distant islands, reefs, clouds and beacon.
Enable this collection in the Outliner to edit the horizon.
The website animates the waves, water and residents at runtime.
The font is embedded. See FONT_NOTICES.txt and manifest.json.
